
/**
 * Write a description of class PlayerMissile here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PlayerMissile
{
    private int x;
    private int y;
    
    public PlayerMissile(int xx, int yy) {x=xx; y= yy;}
    public int getX() {return x;}
    public int getY() {return y;}
    
    public void move() {y-=10;}
    
}
