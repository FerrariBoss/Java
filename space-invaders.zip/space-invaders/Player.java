import java.awt.event.KeyEvent;
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player
{
    private int x;
    private int y;
    public Player() {x = 240; y = 400;}
    public void moveLeft() {x-=10;} 
    public void moveRight() {x+=10;}
    public int getX() {return x;}
    public int getY() {return y;}
    
}
