
/**
 * Write a description of class InvaderMissile here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class InvaderMissile
{
    private int x;
    private int y;
    
    public InvaderMissile(int xx, int yy) {x=xx;y=yy;}
    
    public int getX() {return x;}
    public int getY() {return y;}
    
    public void move() {y+=5;}
    
}
