import javax.swing.JFrame;
import javax.swing.JComponent;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.*;
import java.awt.event.KeyListener;
@SuppressWarnings("serial")
public class KeyBoard extends JPanel {
    double time = 0.0;
    static int frams = 0;
    static Player p = new Player();
    static ArrayList<Invader> invad= new ArrayList<Invader>();
    static ArrayList<PlayerMissile> PMs = new ArrayList<PlayerMissile>();
    static ArrayList<InvaderMissile> AMs = new ArrayList<InvaderMissile>();
    static int health = 100;
    public KeyBoard() {
        KeyListener listener = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                
                
            }

            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                //System.out.println(p.getX()+"\t"+key);
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    
                    p.moveLeft();
                    
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    p.moveRight();
                }
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    double tim2 = System.currentTimeMillis();
                    if (tim2 - time > 600){
                    PMs.add(new PlayerMissile(p.getX()+15,p.getY()));
                    time = tim2;
                    }
                }
                }

            @Override
            public void keyReleased(KeyEvent e) {
                }
        };
        addKeyListener(listener);
        setFocusable(true);
    }
    
    public static void main(String[] args) {
        for (int m = 100; m < 400; m+=20) { invad.add(new Invader(m,100));}
        
        JFrame frame = new JFrame("Space Invader");
        KeyBoard keyboardExample = new KeyBoard();
        frame.add(keyboardExample);
        frame.setSize(500, 500);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        String last = "right";
         
        while (true)
        {
            try {
                Thread.sleep(10);
            }
            catch (Exception E){
                
            }
            
            frame.repaint();
            frams++;
            if (invad.size() == 0) {break;}
            if (health == 0) {break;}
            if (frams % 4 == 0)
            {
                if (last.equals("right") && invad.get(invad.size()-1).getX() > 450)
                {last = "left";for (Invader q: invad){q.moveDown();}}
                if (last.equals("left") && invad.get(0).getX() < 50)
                {last = "right";for (Invader q: invad){q.moveDown();}}
                for (Invader q : invad)
                {
                    boolean exists = true;
                    for (PlayerMissile pm : PMs) {
                        if (pm.getX() >= q.getX() && pm.getX() <= q.getX()+10 && pm.getY() >= q.getY() && pm.getY() <=q.getY()+10){
                            invad.remove(q);exists = false; break; 
                        }
                    }
                    if (!exists){break;}
                    if (last.equals("left")) {q.moveLeft();}
                    else {q.moveRight();}
                }
                for (PlayerMissile pm : PMs) {
                    if (pm.getY() < 0) {PMs.remove(pm);break;}
                    pm.move();
                }
                for (InvaderMissile am : AMs) {
                    if (am.getY() > 450) {AMs.remove(am);health-=10;break;}
                    am.move();
                    
                }
                for (PlayerMissile pm : PMs) {
                    boolean e1 = true;
                    for (InvaderMissile am :AMs) {
                        
                        int a1 = pm.getX() - am.getX();
                        int a2 = pm.getY() - am.getY() ;
                        System.out.println("Player: " + pm.getX() + " "+pm.getY() + " Invader: " + am.getX() +" "+ am.getY() + " A1: " +a1 + " A2: " + a2);
                        if (a1< 15 && a2< 15 && a1 >-2 && a2 > -2) {
                            System.out.println("poop");
                            PMs.remove(pm); e1 = false;
                            AMs.remove(am); break;
                        }
                        if (!e1) {break;}
                    }
                    if (!e1 ) {break;}
                }
            }
            if (frams % 200 == 0) {
                int in = (int)(Math.random() * (invad.size()-1));
                AMs.add(new InvaderMissile(invad.get(in).getX(), invad.get(in).getY()));
            }
        }
        
    }
    public void paintComponent(Graphics g)
    {
        g.drawRect(p.getX(), p.getY(), 30, 5);
        for (Invader i : invad)
        {
            g.drawRect(i.getX(),i.getY(),15,15);
        }
        g.drawLine(50,450,450,450);
        g.drawString(""+frams,200,200);
        for (PlayerMissile pm : PMs) {
            g.drawRect(pm.getX(),pm.getY(),2,5);
        }
        for (InvaderMissile im : AMs) {
            g.drawRect(im.getX(),im.getY(),10,10);
        }
        g.drawString("HEALTH: "+health, 400,400);
        g.drawString("Left and Right arrow to move, Space to shoot " , 150,150);
    }
}