
/**
 * Write a description of class Invader here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Invader
{
    private int x;
    private int y;
    public Invader(int xx, int yy) {x=xx;y=yy;}
    public void moveLeft() {x-=1;}
    public void moveRight() {x+=1;}
    public void moveUp() {y -= 1;}
    public void moveDown() {y += 10;}
    
    public int getX() {return x;}
    public int getY() {return y;}
}
